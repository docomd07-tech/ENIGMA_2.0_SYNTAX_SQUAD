import streamlit as st
import numpy as np
import cv2
import rasterio
import hashlib
from io import BytesIO
from PIL import Image

# ----------------------------
# Page Config
# ----------------------------
st.set_page_config(
    page_title="Stress-Vision | Orbital Agronomy",
    page_icon="🌾",
    layout="wide"
)

# ----------------------------
# Helper Functions
# ----------------------------
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def load_band(file):
    with rasterio.open(file) as src:
        return src.read(1).astype(float)

def normalize(arr):
    arr = np.nan_to_num(arr)
    return (arr - arr.min()) / (arr.max() - arr.min() + 1e-8)

def convert_np_to_image(arr):
    """Convert normalized numpy array to PNG bytes"""
    arr_uint8 = (arr * 255).astype(np.uint8)
    if len(arr.shape) == 2:  # grayscale
        img = Image.fromarray(arr_uint8)
    else:
        img = Image.fromarray(arr_uint8)
    buf = BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return buf

# ----------------------------
# Session State
# ----------------------------
if "users" not in st.session_state:
    st.session_state.users = {}
if "logged_in" not in st.session_state:
    st.session_state.logged_in = False
if "username" not in st.session_state:
    st.session_state.username = ""

# ----------------------------
# Sign-Up / Login Functions
# ----------------------------
def sign_up(username, password):
    if username in st.session_state.users:
        st.error("Username already exists!")
    else:
        st.session_state.users[username] = hash_password(password)
        st.success("Sign-Up successful! Please log in.")

def log_in(username, password):
    hashed = hash_password(password)
    if username in st.session_state.users and st.session_state.users[username] == hashed:
        st.session_state.logged_in = True
        st.session_state.username = username
        st.success(f"Welcome {username}!")
    else:
        st.error("Incorrect username or password!")

# ----------------------------
# Login / Sign-Up Page
# ----------------------------
if not st.session_state.logged_in:
    st.title("🌾 Stress-Vision Login / Sign-Up")
    option = st.radio("Choose action", ["Login", "Sign-Up"])
    username = st.text_input("Username")
    password = st.text_input("Password", type="password")

    if option == "Sign-Up":
        if st.button("Sign Up"):
            if username and password:
                sign_up(username, password)
            else:
                st.warning("Enter both username and password!")
    elif option == "Login":
        if st.button("Log In"):
            if username and password:
                log_in(username, password)
            else:
                st.warning("Enter both username and password!")

# ----------------------------
# Main App After Login
# ----------------------------
if st.session_state.logged_in:
    st.sidebar.title(f"🌾 Welcome {st.session_state.username}!")
    page = st.sidebar.radio(
        "Navigation",
        ["🏠 Home", "📡 Data Acquisition", "📊 Analysis", "Logout"]
    )

    if page == "Logout":
        st.session_state.logged_in = False
        st.session_state.username = ""
        st.experimental_rerun()

    # ----------------------------
    # Home Page
    # ----------------------------
    elif page == "🏠 Home":
        st.title("🌾 Welcome to Stress-Vision")
        st.write("""
        Stress-Vision is a tool for **pre-visual crop stress detection** using Sentinel-2 satellite bands.
        Navigate to **Data Acquisition** to learn how to download the required bands, 
        then go to **Analysis** to upload and analyze your data.
        """)

    # ----------------------------
    # Data Acquisition Page
    # ----------------------------
    elif page == "📡 Data Acquisition":
        st.title("📡 Satellite Data Acquisition")
        st.markdown("### 🛰 Data Source")
        st.write("""
        We use **Sentinel-2 Level-2A surface reflectance data** 
        from the European Space Agency (ESA).
        """)

        st.markdown("### 📥 How to Download Bands")
        with st.expander("Step-by-Step Download Instructions"):
            st.markdown("""
            1️⃣ Go to **Copernicus Data Space**  
            2️⃣ Select **Sentinel-2**  
            3️⃣ Choose **Product Type: L2A**  
            4️⃣ Filter **Cloud Cover < 10%**  
            5️⃣ Select **Analytical Download**  
            6️⃣ Download Bands:
               - B03 (Green)
               - B04 (Red)
               - B05 (Red Edge)
               - B08 (NIR)
               - B11 (SWIR)
            """)
        col1, col2 = st.columns(2)
        col1.markdown("[Open Copernicus Data Space](https://browser.dataspace.copernicus.eu)")
        col2.markdown("[Open USGS EarthExplorer](https://earthexplorer.usgs.gov)")
        st.info("⚠️ Make sure all bands are from the SAME date and SAME location.")

    # ----------------------------
    # Analysis Page
    # ----------------------------
    elif page == "📊 Analysis":
        st.title("📊 Stress-Vision: Crop Stress Analysis")
        st.write("Upload the 5 Sentinel-2 bands (B03, B04, B05, B08, B11) to generate stress heatmaps.")

        # Upload files
        red_file = st.file_uploader("Upload Red Band (B04)", type=["tif"])
        green_file = st.file_uploader("Upload Green Band (B03)", type=["tif"])
        nir_file = st.file_uploader("Upload NIR Band (B08)", type=["tif"])
        swir_file = st.file_uploader("Upload SWIR Band (B11)", type=["tif"])
        red_edge_file = st.file_uploader("Upload Red Edge Band (B05)", type=["tif"])

        if red_file and green_file and nir_file and swir_file and red_edge_file:
            st.info("Processing bands, please wait...")

            # Load bands
            red = load_band(red_file)
            green = load_band(green_file)
            nir = load_band(nir_file)
            swir = load_band(swir_file)
            red_edge = load_band(red_edge_file)

            # Indices & Stress
            ndvi = (nir - red) / (nir + red + 1e-8)
            ndwi = (nir - swir) / (nir + swir + 1e-8)
            red_edge_index = (nir - red_edge) / (nir + red_edge + 1e-8)
            stress = (1 - ndwi) + (1 - ndvi) + (1 - red_edge_index)
            stress = normalize(stress)
            stress_percentage = np.mean(stress) * 100
            rgb = np.dstack((red, green, nir))
            rgb = normalize(rgb)

            stress_uint8 = (stress * 255).astype(np.uint8)
            heatmap = cv2.applyColorMap(stress_uint8, cv2.COLORMAP_JET)
            heatmap = cv2.cvtColor(heatmap, cv2.COLOR_BGR2RGB)

            ndvi_norm = normalize(ndvi)
            ndvi_uint8 = (ndvi_norm * 255).astype(np.uint8)
            ndvi_colormap = cv2.applyColorMap(ndvi_uint8, cv2.COLORMAP_VIRIDIS)
            ndvi_colormap = cv2.cvtColor(ndvi_colormap, cv2.COLOR_BGR2RGB)

            threshold = st.slider("Stress Threshold", 0.0, 1.0, 0.6)
            high_stress_mask = stress > threshold
            mask_display = high_stress_mask.astype(np.uint8) * 255

            stressed_pixels = np.sum(stress > threshold)
            healthy_pixels = np.sum(stress <= threshold)
            total_pixels = stressed_pixels + healthy_pixels
            stressed_percent = (stressed_pixels / total_pixels) * 100
            healthy_percent = (healthy_pixels / total_pixels) * 100

            # ----------------------------
            # Tabs with Download Buttons
            # ----------------------------
            tabs = st.tabs([
                "RGB Composite", "NDVI Map", 
                "Stress Heatmap", "High-Stress Mask", "Crop Health Overview"
            ])

            # Tab 0 - RGB
            with tabs[0]:
                st.subheader("RGB View")
                st.image(rgb, use_container_width=True)
                st.download_button(
                    "📥 Download RGB Image",
                    data=convert_np_to_image(rgb),
                    file_name="RGB.png",
                    mime="image/png"
                )

            # Tab 1 - NDVI
            with tabs[1]:
                st.subheader("NDVI Map")
                st.image(ndvi_colormap, use_container_width=True)
                st.download_button(
                    "📥 Download NDVI Map",
                    data=convert_np_to_image(ndvi_colormap),
                    file_name="NDVI.png",
                    mime="image/png"
                )

            # Tab 2 - Stress Heatmap
            with tabs[2]:
                st.subheader("Stress-Vision Heatmap")
                st.image(heatmap, use_container_width=True)
                st.download_button(
                    "📥 Download Stress Heatmap",
                    data=convert_np_to_image(heatmap),
                    file_name="StressHeatmap.png",
                    mime="image/png"
                )

            # Tab 3 - High-Stress Mask
            with tabs[3]:
                st.subheader("High Stress Zones")
                st.image(mask_display, use_container_width=True)
                st.download_button(
                    "📥 Download High Stress Mask",
                    data=convert_np_to_image(mask_display),
                    file_name="HighStressMask.png",
                    mime="image/png"
                )

            # Tab 4 - Crop Health Overview
            with tabs[4]:
                st.subheader("Average Crop Stress (%)")
                st.metric("Average Crop Stress (%)", f"{stress_percentage:.2f}%")
                st.subheader("Healthy vs Stressed")
                st.bar_chart({
                    "Crop Status": ["Healthy", "Stressed"],
                    "Percentage": [healthy_percent, stressed_percent]
                })