import numpy as np
import rasterio
import cv2

def load_band(file):
    with rasterio.open(file) as src:
        band = src.read(1).astype(float)
    return band

def normalize(array):
    array = np.nan_to_num(array)
    min_val = np.min(array)
    max_val = np.max(array)
    return (array - min_val) / (max_val - min_val + 1e-8)

def calculate_ndvi(nir, red):
    return (nir - red) / (nir + red + 1e-8)

def calculate_ndwi(nir, swir):
    return (nir - swir) / (nir + swir + 1e-8)

def calculate_red_edge_index(nir, red_edge):
    return (nir - red_edge) / (nir + red_edge + 1e-8)

def calculate_stress(ndvi, ndwi, red_edge):
    stress = (1 - ndwi) + (1 - ndvi) + (1 - red_edge)
    return normalize(stress)

def create_rgb(red, green, nir):
    rgb = np.dstack((red, green, nir))
    return normalize(rgb)

def create_heatmap(stress):
    stress_uint8 = (stress * 255).astype(np.uint8)
    heatmap = cv2.applyColorMap(stress_uint8, cv2.COLORMAP_JET)
    heatmap = cv2.cvtColor(heatmap, cv2.COLOR_BGR2RGB)
    return heatmap